<?php
class Login {
 private $id;
 private $email;
 private $senha;
 /**
 * ...
 * getters e setters
 * ...
 *
 */

 public function insert() {
 // logica para salvar cliente no banco
 }

 public function select() {
 // logica para remover cliente do banco
 }
